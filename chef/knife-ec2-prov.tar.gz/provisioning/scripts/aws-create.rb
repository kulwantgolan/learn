#!/usr/bin/env ruby

require "rubygems"
require 'highline'
require "highline/import"
require "json"

cli = HighLine.new

puts ""
nodename    = cli.ask("Node Name?  ") { |q| q.default = "" }
#az          = cli.ask("Availability Zone?  ") { |q| q.default = "" }
serverurl   = cli.ask("Chef Server URL?  ") { |q| q.default = "https://chef.catapult-elearning.net" }
if cli.agree("Automatically acquire a new Elastic IP address? ") then
  eip = ''
  while eip == ''
    my_json = JSON.parse(`aws ec2 describe-addresses`)
    my_json['Addresses'].each do |addr|
      unless addr.key?('AssociationId') then 
        eip = addr['PublicIp']  # If an entry lacks an associationID we can use it
      end
    end
    unless eip != ''
      system('aws ec2 allocate-address --domain vpc 2>&1 1> /dev/null')
    end
  end
else
  eip         = cli.ask("Existing elastic IP address to associate with instance? ") { |q| q.default = "" }
end
if cli.agree("Disable termination of this instance?  ") then
  disableterm = '--disable-api-termination'
end
termdelebs  = cli.agree("Keep EBS volume after instance has been terminated?  ")
if cli.agree("Enable optimised EBS I/O?  ") then
  optimiseebs = '--ebs-optimized'
end
ebstype     = cli.ask("EBS volume type? (io1 | gp2 | st1 | sc1 | standard)  ") { |q| q.validate = /(io1|gp2|st1|sc1|standard)/}
if ebstype == "io1"
  proviops    = cli.ask("Provisioned IOPS rate?  ", Integer)
end
ebssize     = cli.ask("EBS volume size in GB?  ", Integer)
stdflavour  = cli.agree("Select instance type from the commonly used list?  ")
if stdflavour
  flavours = %w{ t2.micro t2.small t2.medium t2.large m4.large m4.xlarge c4.large c4.xlarge c4.2xlarge }
else
  flavours = %w{ t2.nano t2.micro t2.small t2.medium t2.large m4.large m4.xlarge m4.2xlarge m4.4xlarge m4.10xlarge 
                   m3.medium m3.large m3.xlarge m3.2xlarge c4.large c4.xlarge c4.2xlarge c4.4xlarge c4.8xlarge c3.large c3.xlarge 
                   c3.2xlarge c3.4xlarge c3.8xlarge g2.2xlarge g2.8xlarge x1.32xlarg r3.large r3.xlarge r3.2xlarge r3.4xlarge 
                   r3.8xlarge i2.xlarge i2.2xlarge i2.4xlarge i2.8xlarge d2.xlarge d2.2xlarge d2.4xlarge d2.8xlarge }
end
ec2flavour = ''
choose do |menu|
  menu.prompt = "Select an instance type from the list:"
  menu.choices(*flavours) do |chosen|
    ec2flavour = chosen
  end
end
image       = cli.ask("Amazon Machine Image? (default is Ubuntu 14.04 HVM) ") { |q| q.default = "ami-6c14310f" }
sshuser     = cli.ask("SSH user for this image? ") { |q| q.default = "ubuntu" }
region      = cli.ask("AWS Region? ") { |q| q.default = "ap-southeast-2" }
secgroups   = cli.ask("Security group IDs? Comma-separated list. Make sure you allow SSH :)") { |q| q.default = "sg-fa008b9e" }
subnet = ''
choose do |menu|
  menu.prompt = "Select a subnet from the list:"
  subnets = [
    "Availability Zone A, Public Subnet",
    "Availability Zone B, Public Subnet",
    "Availability Zone C, Public Subnet",
    "Availability Zone A, DMZ Subnet",
    "Availability Zone B, DMZ Subnet",
    "Availability Zone C, DMZ Subnet",
  ]
  menu.choices(*subnets) do | chosen|
    case chosen
    when "Availability Zone A, Public Subnet" 
      subnet = 'subnet-13cc9476'
    when "Availability Zone B, Public Subnet"
      subnet = 'subnet-2f3a7b58'
    when "Availability Zone C, Public Subnet"
      subnet = 'subnet-b54067f3'
    when "Availability Zone A, DMZ Subnet"
      subnet = 'subnet-58fba33d'
    when "Availability Zone B, DMZ Subnet"
      subnet = ''
    when "Availability Zone C, DMZ Subnet"
      subnet = ''
    end
  end
end
aws_ssh_key = cli.ask("Name of an AWS SSH key (preferably one for which you have the private key)? ")
runlist     = cli.ask("Initial list of Chef recipes? Comma-separated list.") { |q| q.default = "role[linux-server]" }
verbosity   = ''
verbose     = cli.agree("Verbose? ")
if verbose then 
  verbosity = '-V'
  vverbose = cli.agree("...very verbose? ") 
  if vverbose then
    verbosity = '-VV'
  end
end

commandout = "knife ec2 server create -N #{nodename} -I #{image} -f #{ec2flavour} --associate-eip #{eip} --subnet #{subnet} #{disableterm} #{optimiseebs} --ebs-size #{ebssize} --run-list #{runlist} -S #{aws_ssh_key} --ssh-user #{sshuser} -g #{secgroups} #{verbosity}"
puts commandout

