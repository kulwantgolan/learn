require 'json'
target_address = ''
while target_address == ''
  my_json = JSON.parse(`aws ec2 describe-addresses`)
  my_json['Addresses'].each do |addr|
    unless addr.key?('AssociationId') then 
      target_address = addr['PublicIp']  # If an entry lacks an associationID we can use it
    end
  end
  unless target_address != ''
    system('aws ec2 allocate-address --domain vpc 2>&1 1> /dev/null')
  end
end
puts target_address
